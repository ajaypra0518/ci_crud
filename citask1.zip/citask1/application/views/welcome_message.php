<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
		integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
<style>
	table tr th{
		padding-right:50px;
		
	}
	table tr td{
	padding:8px 15px;
	padding-left:0;
		
	}
	.alertshow{
		color:green;
	}

</style>
</head>

<body>
	<div class="container mt-5">
		<div class="row">
			<div class="col-5 mx-auto">
				<div class="alertshow">
				<?php echo $this->session->flashdata('message'); ?>
				</div>
				<form method="POST" action="Welcome/insert_data">
					<div class="form-group">
						<label>Name</label>
						<input type="text" class="form-control" id="name" aria-describedby="emailHelp" name="name"
							required>
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="text" class="form-control" id="password" name="password" required>
					</div>
					<button type="submit" class="btn btn-primary btn-block">Submit</button>
				</form>
			</div>
		</div>
	</div>
	<div class="container mt-5">
		<div class="row">
			<div class="col-5 mx-auto">
				<table>
				<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Password</th>
				<th>Delete</th>
				<th>Update</th>
				</tr>
					<?php
					$i=1;
					foreach($student as $row){
					?>
					
					<tr>
						<td><?php echo $i; ?></td>
						<td><?php echo $row['name']; ?></td>
						<td><?php echo $row['password']; ?></td>

						<td>
						<form action="Welcome/remove_data" method="POST">
						<input type="hidden" value="<?php echo $row['id'];?>" name="delid">
						<button type="submit" class="btn btn-danger" name="d1" onclick="return confirm('Do you want to delete?')">Delete</button>
						</form>
						</td>

						<td>
						<form action="Welcome/select_update_data" method="POST">
						<input type="hidden" value="<?php echo $row['id'];?>" name="updateid">
						<button type="submit" class="btn btn-success"  >Update</button>
						</form>
						</td>
					</tr>
						
					<?php
					$i++;
					}
					?>

				</table>
			</div>
		</div>

	</div>

</body>

</html>