<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
		integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
<style>
	table tr th{
		padding-right:50px;
		
	}
	table tr td{
	padding:8px 15px;
	padding-left:0;
		
	}

</style>
</head>

<body>
	<div class="container mt-5">
		<div class="row">
			<div class="col-5 mx-auto">
                <form method="POST" action="http://localhost/citask1/Welcome/update_data">
                <input type="hidden" name="id" value="<?php echo $student[0]['id']; ?>">
					<div class="form-group">
						<label>Name</label>
						<input type="text" class="form-control" id="name" aria-describedby="emailHelp" name="name"
							value="<?php echo $student[0]['name']; ?>" required>
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="text" class="form-control" id="password" name="password" value="<?php echo $student[0]['password']; ?>" required>
					</div>
					<button type="submit" class="btn btn-primary btn-block">Submit</button>
				</form>
			</div>
		</div>
	</div>


</body>

</html>