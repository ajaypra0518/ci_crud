<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	 public function __construct(){
		 parent::__construct();
		 $this->load->model('ModelCrud','modelcrud');
	 }
	
	public function index()
	{
		$data['student']=$this->modelcrud->showData('student');
		$this->load->view('welcome_message',$data);
	}

	public function insert_data()
	{
	// $data=array(
	// 	'name'=>$this->input->post('name'),
	// 	'password'=>$this->input->post('password')
	// );
		$data=$this->input->post();

		$x=$this->modelcrud->insertData('student',$data);
		if($x){
			header('location:../Welcome');
		}
		else{
			echo "data not inserted";
		}
	}

	public function remove_data(){
		$id=$this->input->post('delid');
		$x=$this->modelcrud->deleteData($id);
		if($x){
			$this->session->set_flashdata('message','Data deleted Succesfully');
			header('location:http://localhost/citask1/Welcome');
		}
		else{
			echo 
			"<script>
			alert('not deleted');
			window.location.href='http://localhost/citask1/Welcome';
			</script>";
		}
	}

	public function select_update_data(){
		$id=$this->input->post('updateid');
		$data['student']=$this->modelcrud->selectUpdateData($id);
		$this->load->view('update',$data);
	}
	public function update_data(){
		$id=$this->input->post('id');
		$data=array(
			'name'=>$this->input->post('name'),
			'password'=>$this->input->post('password')
		);
		$x=$this->modelcrud->updateData($id,$data);
		if($x){
			echo 
			"<script>
			alert('upadted');
			window.location.href='http://localhost/citask1/Welcome';
			</script>";
		}
		else{
			echo 
			"<script>
			alert('not upadted');
			window.location.href='http://localhost/citask1/Welcome';
			</script>";
		}
	}
	
}
