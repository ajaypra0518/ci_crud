<?php
class ModelCrud extends CI_Model {

	
	public function insertData($tblname,$data)

	{
        $x= $this->db->insert($tblname,$data);
        return $x;
    }
    public function showData($tblname){
        $data=$this->db->get($tblname);
        return $data->result_array();
    }

    public function deleteData($id){
        $this->db->where('id', $id);
        $x=$this->db->delete('student');
        return $x;
    }
    public function selectUpdateData($id){
        $this->db->select('*');
        $this->db->from('student');
        $this->db->where('id', $id);
        $data = $this->db->get();
        return $data->result_array();
    }

    public function updateData($id,$data){
        $this->db->where('id', $id);
        $x=$this->db->update('student', $data);
        return $x;
    }
}

?>